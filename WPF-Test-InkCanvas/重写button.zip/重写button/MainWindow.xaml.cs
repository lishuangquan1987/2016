﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace 重写button
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            
        }

        private void btn_Click(object sender, RoutedEventArgs e)
        {
            Button b = (Button)sender;
            string toolTip = b.ToolTip.ToString();
            if (toolTip == "播放")
            {
                b.SetValue(Button.StyleProperty, Application.Current.Resources["buttonPause"]);
                b.ToolTip = "暂停";
                Play();
                
            }
            else
            {
                b.SetValue(Button.StyleProperty,Application.Current.Resources["buttonPlay"]);
                b.ToolTip = "播放";
            }
        }
        void Play()
        {
            string path = @"D:\KuGou\Listen\南征北战 - 我的天空 - 影片剪辑版 - 《青春派》 电影原声.mp3";
            MediaPlayer player = new MediaPlayer();
            player.Open(new Uri(path));
            player.Play();
        }
    }
}
